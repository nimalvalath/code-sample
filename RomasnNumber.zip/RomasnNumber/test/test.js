
QUnit.test('RomanTest',function(assert) {
    assert.equal(receiverfunction('xxx','+','x'),'XL','XXX + X = XL');
    assert.equal(receiverfunction('xx','+','x'),'XXX','XX + X = XXX');
    assert.equal(receiverfunction('xxx','-','x'),'XX','XXX - X = XX');
    assert.equal(receiverfunction('xxx','/','x'),'III','XXX / X = III');
    assert.equal(receiverfunction('xxx','*','x'),'CCC','XXX * X = CCC');
    assert.equal(receiverfunction('x','-','x'),'0-not in roman','x-x=0-not in roman');
    assert.equal(receiverfunction('A','-','x'),'invalid','invalid operand');
    assert.equal(receiverfunction('','-','x'),'invalid','invalid operand');
    assert.equal(receiverfunction('A','x','x'),'invalid','invalid operator');
    assert.equal(receiverfunction('x','-','xx'),'X','minus x');
		
		

});
