var numeralCodes = [["","I","II","III","IV","V","VI","VII","VIII","IX"],         // Ones
                    ["","X","XX","XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"],   // Tens
                    ["","C","CC","CCC","CD","D","DC","DCC","DCCC","CM"],		//hundred
                    ["","M","MM","MMM","Mↁ","ↁ","ↁM","ↁMM","ↁMMM","Mↂ"]]; 		//thousands
                    //can be appended  	using ↂ to ten thousands
//by adding appropriate symbols like ↁ -5000,ↂ -10000 : 
//ↁ is a unicode substitute for v(bar)  
//ↂ is a unicode substitute for x(bar) etc 
//program can be extended 
var symbols=["I","x","L","C","D","M"];   
var symbolToNumArray;
var romNumFirst,upperNUM1;
var opr;
var romNumSecond,upperNUM2;

var equv_decimalNum1=0;
var equv_decimalNum2=0;
var romanResult="invalid input";

function receiverfunction(param_firstnum,param_opr,param_secondnum){

//receive inputs and convert to upper case is  necessary	
romNumFirst=param_firstnum.trim();

upperNUM1=romNumFirst.toUpperCase();
equv_decimalNum1=convertSample(upperNUM1);

//debugging purpose for programmer
console.log(upperNUM1);
console.log("/////////")
console.log(equv_decimalNum1);
//debugging purpose for programmer
opr=param_opr.trim();

romNumSecond=param_secondnum.trim();
upperNUM2=romNumSecond.toUpperCase();
equv_decimalNum2=convertSample(upperNUM2);

//debugging purpose for programmer

console.log("/////////")
console.log(equv_decimalNum2);
console.log(upperNUM2);
console.log(romNumFirst+" "+opr+" "+romNumSecond);
console.log(upperNUM1+" "+opr+" "+upperNUM2);
//debugging purpose for programmer

//checking and validation of roman starts here
if(upperNUM1.length>=1 && opr.length==1 && upperNUM2.length>=1){

// REGX for checking roman numerals

	if((upperNUM1.match(/^[IVXLCM]+$/g)!==null) && ((upperNUM2.match(/^[IVXLCM]+$/g)!==null))){
		
		//identify operator and do operations:

		switch(opr){
			case "+":
					//debugging purpose for programmer

					//equv_decimalNum1=convertRomanToNumber();
					//convertSample();
					console.log(opr);
					console.log(symbols)
					console.log("////result///");
					console.log(equv_decimalNum1+equv_decimalNum2);
					//debugging purpose for programmer
					
					//calculation

					var output=equv_decimalNum1+equv_decimalNum2;

					//debugging purpose for programmer	
					//console.log(equv_decimalNum1);
					//document.getElementById("result").innerHTML=""+output;
					//debugging purpose for programmer

					romanResult= convert(output);
					//debugging purpose for programmer
					console.log("//////final roman result///");
					console.log(romanResult);
					//debugging purpose for programmer

					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"="+romanResult;
					
					break;
			case "-":
					//debugging purpose for programmer
					console.log(opr);
					console.log(symbols)
					console.log("////result///");
					console.log(equv_decimalNum1-equv_decimalNum2);
					//debugging purpose for programmer

					//CALCULATION
					
					var output=equv_decimalNum1 - equv_decimalNum2;

					//debugging purpose for programmer
					//console.log(equv_decimalNum1);
					//document.getElementById("result").innerHTML=""+output;
					//debugging purpose for programmer	

					//result validation checking conditions STARTS HERE 
					//FOR THIS SECTION

					if(output < 0){
					output=Math.abs(output)
					romanResult= convert(output);
					
					//debugging purpose for programmer					
					console.log("//////final roman result///");
					console.log(output);
					console.log("negative"+romanResult);
					//debugging purpose for programmer
					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"= negative "+romanResult;
					
					}
					else if(output == 0){
					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"= 0";
					console.log(output);
					console.log(romanResult);
					romanResult='0-not in roman';	
					}
					else{
					romanResult= convert(output);
					//debugging purpose for programmer
					console.log("//////final roman result///");
					console.log(output);
					console.log(romanResult);
					//console.log(romanResult);
					//debugging purpose for programmer
					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"= negative "+romanResult;
					
					}
					
					break;
			case "*":
					//debugging purpose for programmer
					console.log(opr);
					console.log(symbols)
					console.log("////result///");
					console.log(equv_decimalNum1*equv_decimalNum2);
					//debugging purpose for programmer
					
					//CALCULATION

					var output=equv_decimalNum1 * equv_decimalNum2;
					//debugging purpose for programmer
					//console.log(equv_decimalNum1);
					//document.getElementById("result").innerHTML=""+output;
					//debugging purpose for programmer

					romanResult= convert(output);
					//debugging purpose for programmer
					console.log("//////final roman result///");
					console.log(output);
					console.log(romanResult);

					//debugging purpose for programmer
					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"="+romanResult;
					
					break;
			case "/":
					//DIVISION OPERATION
					//debugging purpose for programmer
					console.log(opr);
					console.log(symbols)
					console.log("////result///");
					console.log(equv_decimalNum1 / equv_decimalNum2);
					//debugging purpose for programmer
					if(equv_decimalNum2 != 0){
					var output=equv_decimalNum1 / equv_decimalNum2;
					
					//debugging purpose for programmer
					console.log(output);
					//document.getElementById("result").innerHTML=""+output;

					//CONDITION CHECKING FOR RESULT VALIDATION
					output=Math.floor(output);
					if(output == 0){
					romanResult=0;
					console.log(romanResult);
					}
					else{
					romanResult= convert(output);
					//debugging purpose for programmer
					console.log("*************");
					console.log(output);
					console.log(romanResult);
					//debugging purpose for programmer
					}
					
					//CHECKING FOR REMAINDER

					var remainder= equv_decimalNum1 % equv_decimalNum2;
					if(remainder >0){
					var romanRemainder=convert(remainder);
					//debugging purpose for programmer
					console.log("//////final roman result///");
					console.log(output);
					console.log(romanRemainder);
					console.log(romanResult);
					//debugging purpose for programmer
					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"="+romanResult+" remainer"+ romanRemainder;
				
					}
					else{
					//document.getElementById("result").innerHTML=""+upperNUM1+" "+opr+" "+upperNUM2+"="+romanResult+" remainer 0";
					console.log("remainer is 0"+romanResult);
					}
					
					}
					else{
					//document.getElementById("result").innerHTML="cannot complete logically";
					console.log("cannot complete logically");
					}
					
					break;
			default:

					console.log("operator error");		

					romanResult='invalid operator';
		}

	}
	else{
		//VALIDATION MSGS TO USER:

	window.alert("Please specify the Roman numerals in standard format: ");
	romanResult='invalid';
	}

		

}
else{
	//VALIDATION MSGS TO USER
window.alert("1. Please specify the Roman numerals in standard format \n2. Numerous operators are not allowed \n3. To learn about roman numerals please visit \n https://en.wikipedia.org/wiki/Roman_numerals");
romanResult='invalid';
}
return romanResult;
}	
//INITIAL INPUT VALIDATION GOES HERE
function validateInput(param_firstnum,param_opr,param_secondnum){



if ( param_firstnum.trim().length==0|| param_opr.trim().length==0 || param_secondnum.trim().length==0){
	window.alert("Please enter some valid input");
}
}
//RESET INPUT HERE
function clearInputs() {
	console.log("used to clear inputs");
	//document.getElementById("num1").value="";
	//document.getElementById("opr1").value="";
	//document.getElementById("num2").value="";
	//document.getElementById("result").innerHTML="Result??";

}

function convertSample(justNum){
	console.log("i am inside sample");
	var tempNum1=justNum;
	console.log(tempNum1);
	//if(tempNum1.length > 1)
	console.log(tempNum1.split("").reverse());
	//var tempData=tempNum1.split("").reverse();
	symbolToNumArray=new Array(tempNum1.length);
	console.log(symbolToNumArray);
	for(var i=0;i<tempNum1.length;i++){
//		CAN BE EXTENDED UP TO 100,000 
//		BY USING APPROPRIATE SYMBOLS
//		if(tempNum1[i]=="ↁ")
//			symbolToNumArray[i]=5000;

		if(tempNum1[i]=="M")
			symbolToNumArray[i]=1000;
		else if(tempNum1[i]=="D")
			symbolToNumArray[i]=500;
		else if(tempNum1[i]=="C")
			symbolToNumArray[i]=100;
		else if(tempNum1[i]=="L")
			symbolToNumArray[i]=50;
		else if(tempNum1[i]=="X")
			symbolToNumArray[i]=10;
		else if(tempNum1[i]=="V")
			symbolToNumArray[i]=5;
		else if(tempNum1[i]=="I")
			symbolToNumArray[i]=1;
	}
	console.log(symbolToNumArray);
	
	var res=0;
	
	for( var i=0;i<symbolToNumArray.length;i++){
		
		var s1 = symbolToNumArray[i];
		if(i+1<symbolToNumArray.length){
				var s2 = symbolToNumArray[i+1];	
				if (s1 >= s2){
					res+=s1;
				}
				else{
					res = res + s2 - s1;
					i++;
				}

			}
			else{
				res = res + s1;
            	i++;
			}


	}
	console.log(res);
	console.log("end")
	return res;
}


function validation(romNum,op,romSecond){
	console.log(romNum+" "+op+" "+romSecond);
}
//CONVERTING ROMAN TO NUMBER HERE

function convertRomanToNumber(){

var temp_Char_numeral=upperNUM1;
var sum=0;


	if(temp_Char_numeral.indexOf("III") >= 0){
		sum = sum + 3;
		temp_Char_numeral.replace("III","");

		
	}
	else if(temp_Char_numeral.indexOf("II") >= 0){
		sum=sum + 2;
		temp_Char_numeral.replace("II","");
		
	}
	else if(temp_Char_numeral.indexOf("I") >= 0){
		sum= sum + 1;
		temp_Char_numeral 
		.replace("I","");
		
	}

 return sum;

}


//CONVERT NUMBER TO ROMAN HERE      

function convert(num) {
  var numeral = "";
  var digits = num.toString().split('').reverse();
  for (var i=0;i < digits.length; i++){
    numeral = numeralCodes[i][parseInt(digits[i])] + numeral;
  }
  return numeral;  
}



